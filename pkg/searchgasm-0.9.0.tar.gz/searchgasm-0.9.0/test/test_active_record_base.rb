require File.dirname(__FILE__) + '/test_helper.rb'

class TestActiveRecordBase < Test::Unit::TestCase
  fixtures :accounts, :users, :orders
  
  def setup
    setup_db
    load_fixtures
  end
  
  def teardown
    teardown_db
  end
  
  def test_valid_find_options
    assert_equal [ :conditions, :include, :joins, :limit, :offset, :order, :select, :readonly, :group, :from, :lock ], ActiveRecord::Base.valid_find_options
  end
  
  def test_build_search
    search = Account.build_search(:conditions => {:name_keywords => "awesome"}, :page => 2, :per_page => 15)
    assert_kind_of BinaryLogic::Searchgasm::Search::Base, search
    assert_equal Account, search.klass
    assert_equal "awesome", search.conditions.name_keywords
    assert_equal 2, search.page
    assert_equal 15, search.per_page
  end
  
  def test_searching
    assert_equal Account.find(1, 3), Account.all(:conditions => {:name_contains => "Binary"})
    assert_equal [Account.find(1)], Account.all(:conditions => {:name_contains => "Binary", :users => {:first_name_starts_with => "Ben"}})
    assert_equal [], Account.all(:conditions => {:name_contains => "Binary", :users => {:first_name_starts_with => "Ben", :last_name => "Mills"}})
    
    read_only_accounts = Account.all(:conditions => {:name_contains => "Binary"}, :readonly => true)
    assert read_only_accounts.first.readonly?
    
    assert_equal Account.find(1, 3), Account.all(:conditions => {:name_contains => "Binary"}, :page => 2)
    assert_equal [], Account.all(:conditions => {:name_contains => "Binary"}, :page => 2, :per_page => 20)
  end
  
  def test_counting
    assert_equal 2, Account.count(:conditions => {:name_contains => "Binary"})
    assert_equal 1, Account.count(:conditions => {:name_contains => "Binary", :users => {:first_name_contains => "Ben"}})
  end
  
  def test_scoping
    assert_equal({}, Account.send(:scope, :find))
  end
end
